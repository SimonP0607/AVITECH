create definer = root@localhost view vista_estado_galpones as
select `g`.`id_galpon`        AS `id_galpon`,
       `g`.`nombre`           AS `nombre_galpon`,
       `l`.`nombre_lote`      AS `nombre_lote`,
       `l`.`estado`           AS `estado_lote`,
       `g`.`capacidad`        AS `capacidad`,
       `g`.`estado_sanitario` AS `estado_sanitario`,
       `u`.`usuario`          AS `responsable`
from ((`avicola2`.`galpones` `g` join `avicola2`.`lote` `l`
       on ((`g`.`Id_lote` = `l`.`Id_lote`))) left join `avicola2`.`usuarios` `u`
      on ((`g`.`id_usuario` = `u`.`id_usuario`)));

