create definer = root@localhost view vista_inventario_valorizado as
select `avicola2`.`medicamentos`.`Id_Medicamento`                                       AS `Id_Medicamento`,
       `avicola2`.`medicamentos`.`nombre`                                               AS `nombre`,
       `avicola2`.`medicamentos`.`presentacion`                                         AS `presentacion`,
       `avicola2`.`medicamentos`.`stock`                                                AS `stock`,
       `avicola2`.`medicamentos`.`stock_minimo`                                         AS `stock_minimo`,
       `avicola2`.`medicamentos`.`valor_unitario`                                       AS `valor_unitario`,
       (`avicola2`.`medicamentos`.`stock` * `avicola2`.`medicamentos`.`valor_unitario`) AS `valor_total_stock`
from `avicola2`.`medicamentos`;

